$(function () {
  // alert("worked");
  var score = 0;
  var highScore;
  var counter = 10;
  var randPos = [];
  var timer = setInterval(decrement, 1000);

  function isReloaded() {
    $(window).keydown(function (e) {
      if (e.which == 116 || e.which == 17) {
        return true;
      }
    });
  }

  isReloaded();

  while (randPos.length < 3) {
    var randNum = Math.floor(Math.random() * 16);
    if (randPos.indexOf(randNum) === -1) {
      randPos.push(randNum);
    }
  }

  function pickCell() {
    var randNum = Math.floor(Math.random() * 16);
    var i = 0;
    while (i < randPos.length) {
      if (randPos.indexOf(randNum) === -1) {
        randPos.push(randNum);
        return randNum;
      } else {
        randNum = Math.floor(Math.random() * 16);
      }
      i++;
    }
  }

  //flag for checking whether any of the boxes showed at the beginning are clicked
  var flag = false;
  var final = localStorage.getItem("final");
  final = highScore === null ? 0 : highScore;

  for (var i = 0; i < randPos.length; i++) {
    var randCell = $(".gameBoard td").eq(randPos[i]);
    randCell.css({ backgroundColor: "#000" });
    randCell.click(function () {
      flag = true;
      var randScore = counter;
      score += randScore;
      $(".score").text(score);
      $(this)
        .text("+" + randScore)
        .css({ color: "#3e4444" })
        .animate(function () {
          $(this).text().fadeIn(500).fadeOut(500);
        })
        .animate({ opacity: 0 }, 300)
        .css({ background: "#38FE7F" })
        .animate({ opacity: 0 }, 300)
        .off();
    });
    flag = false;
  }

  function decrement() {
    var counter = parseInt($(".time").text());
    counter--;
    if (counter >= 0) {
      $(".time").text(counter);
      var randNum = pickCell();
      if (flag) {
        var newrandCell = $(".gameBoard td").eq(randNum);
        newrandCell.animate({ backgroundColor: "#000" }, 300);
        newrandCell.click(function () {
          randScore = counter;
          score += randScore;
          $(".score").text(score);
          $(this)
            .text("+" + randScore)
            .css({ color: "#3e4444" })
            .animate(function () {
              $(this).text().fadeIn(500).fadeOut(500);
            })
            .animate({ opacity: 0 }, 300)
            .css({ background: "#38FE7F" })
            .animate({ opacity: 0 }, 300)
            .off();
        });
      }
      if (score > highScore) {
        highScore = score;
      }
      localStorage.setItem("final", final);
      $(".highScore").text(final);
      $(".scoreBar").animate(
        {
          width: counter * 50,
        },
        1000
      );
    } else {
      if (final > score) {
        var add = `<script src="./jquery.confetti.js"></script>
                <script>
                    $.confetti.start();
                    setTimeout(() => {
                    $.confetti.stop();
                  }, 3000)
                </script>`;
        $("#confetti").append(add);
        $("#confetti").addClass(".confetti");
      } else if (isReloaded() == true) {
        var start = "startPage.html";
        $(location).attr("href", start);
        // location.replace("startPage.html");
        // console.log(isReloaded());
      }
    }
  }
});
